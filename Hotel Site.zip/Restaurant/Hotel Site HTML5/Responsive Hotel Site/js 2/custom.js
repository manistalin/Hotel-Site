$(document).ready(function(){
    'use strict';
    
    $(window).scroll(function(){
        
        
    });
    
});